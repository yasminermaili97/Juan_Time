<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <script>
        async function getUser() {
            const token = localStorage.getItem("token");
            if (!token) {
                console.warn("No hay token, redirigiendo al login...");
                return window.location.href = "/login";
            }

            try {
                const response = await fetch("/api/user", {
                    headers: {
                        "Authorization": `Bearer ${token}`,
                        "Content-Type": "application/json"
                    }
                });

                if (!response.ok) {
                    throw new Error("Sesión expirada o token inválido.");
                }

                const data = await response.json();
                document.getElementById("username").textContent = data.name;
            } catch (error) {
                alert("Sesión expirada, inicie sesión nuevamente.");
                localStorage.removeItem("token");
                window.location.href = "/login";
            }
        }

        function logout() {
            localStorage.removeItem("token");
            window.location.href = "/login";
        }

        window.onload = getUser;
    </script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-lg p-4">
            <h2 class="mb-4">Bienvenido, <span id="username" class="text-primary"></span></h2>
            <a href="/watches" class="btn btn-outline-primary me-2">Administrar Relojes</a>
            <button onclick="logout()" class="btn btn-danger">Cerrar Sesión</button>
        </div>
    </div>

    <!-- Bootstrap Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
